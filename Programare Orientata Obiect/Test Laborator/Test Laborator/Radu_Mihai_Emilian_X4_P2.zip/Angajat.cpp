//
//  Angajat.cpp
//  Test Laborator
//
//  Created by Emilian Radu on 05/06/2019.
//  Copyright © 2019 Emilian Radu. All rights reserved.
//

#include <stdio.h>
#include "Angajat.h"

Angajat(string nume, int salariu, int id){
    this->nume = nume;
    this->salariu = salariu;
    this->id = id;
};
